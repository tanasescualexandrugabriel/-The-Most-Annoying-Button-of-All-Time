// Calculates a safe pixel position for the button based on the current
// browser window size, so it never spawns partly off-screen.
function calculeazaPozitieNoua(latimeButon, inaltimeButon, margine = 30) {
    const limitaX = Math.max(margine, window.innerWidth - latimeButon - margine);
    const limitaY = Math.max(margine, window.innerHeight - inaltimeButon - margine);
    const x = margine + Math.floor(Math.random() * (limitaX - margine));
    const y = margine + Math.floor(Math.random() * (limitaY - margine));
    return { x, y };
}

// Returns text/color upgrades for the button as it becomes more annoying
// with each missed attempt.
function obtineEvolutieButon(scor) {
    if (scor === 5)  return { text: "Too slow for 1M$! ⚡", clasa: "btn-warning text-dark" };
    if (scor === 12) return { text: "Are you getting mad? 🧐", clasa: "btn-danger text-white" };
    if (scor === 20) return { text: "ULTRA SPEED MODE 🏎️", clasa: "btn-dark text-danger border-danger" };
    if (scor === 35) return { text: "NO MONEY FOR YOU! 🛑", clasa: "btn-secondary text-white" };
    return null;
}
