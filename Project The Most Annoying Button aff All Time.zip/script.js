const buton = document.getElementById("crazy-btn");
const textScor = document.getElementById("score");
const interfataJoc = document.getElementById("game-ui");
const alertaSucces = document.getElementById("success-alert");
const winExplainer = document.getElementById("win-explainer");
const resetBtn = document.getElementById("reset-btn");

let scorFugi = 0;
let aCastigat = false;

// Shared "run away" logic for both mouse and touch, so the button is
// equally impossible to catch on desktop and on mobile.
function fugiDeCursor() {
    if (aCastigat) return;

    scorFugi++;
    textScor.innerText = scorFugi;

    const coordonate = calculeazaPozitieNoua(buton.offsetWidth, buton.offsetHeight);

    // Drop the CSS centering transform and switch to exact pixel positioning.
    buton.style.transform = "none";
    buton.style.left = coordonate.x + "px";
    buton.style.top = coordonate.y + "px";

    // Extra motion via Animate.css
    buton.classList.add("animate__wobble");
    setTimeout(() => buton.classList.remove("animate__wobble"), 200);

    const evolutie = obtineEvolutieButon(scorFugi);
    if (evolutie) {
        buton.innerText = evolutie.text;
        buton.className = `btn ${evolutie.clasa} btn-lg shadow-lg position-absolute rounded-pill px-5 py-3 fw-bold border-3 border-white animate__animated`;

        document.body.classList.add("flash-white");
        setTimeout(() => document.body.classList.remove("flash-white"), 200);
    }
}

// Desktop mouse
buton.addEventListener("mouseover", fugiDeCursor);

// Mobile touch equivalent - without this, "mouseover" never fires before
// "click" on a touch device and the button would be caught on the first tap.
buton.addEventListener("touchstart", fugiDeCursor, { passive: true });

// Fires only when a click reaches the button without a prior mouseover or
// touchstart - in practice this means Tab + Enter/Space from a keyboard.
buton.addEventListener("click", () => {
    if (aCastigat) return;
    aCastigat = true;

    document.body.classList.add("quake-effect");
    setTimeout(() => document.body.classList.remove("quake-effect"), 400);

    interfataJoc.classList.add("d-none");
    buton.classList.add("d-none");
    alertaSucces.classList.remove("d-none");

    if (winExplainer) {
        winExplainer.textContent =
            `It dodges every mouse and every tap, but a keyboard click never triggers a "hover" first - so Tab + Enter always lands. Missed attempts: ${scorFugi}.`;
    }

    if (typeof confetti === "function") {
        confetti({
            particleCount: 200,
            spread: 100,
            origin: { y: 0.6 }
        });
    }
});

// Full reset back to the native centered state.
function reseteazaJocul() {
    scorFugi = 0;
    aCastigat = false;
    textScor.innerText = scorFugi;
    document.body.classList.remove("quake-effect");

    alertaSucces.classList.add("d-none");
    interfataJoc.classList.remove("d-none");

    buton.className = "btn btn-info btn-lg shadow-lg position-absolute rounded-pill px-5 py-3 fw-bold border-3 border-white animate__animated";
    buton.innerText = "Click for 1M$! 🎯";

    buton.style.top = "65%";
    buton.style.left = "50%";
    buton.style.transform = "translate(-50%, -50%)";
    buton.classList.remove("d-none");
}

if (resetBtn) {
    resetBtn.addEventListener("click", reseteazaJocul);
}

// Exposed globally too, in case you'd rather wire it with onclick="reseteazaJocul()" in HTML.
window.reseteazaJocul = reseteazaJocul;
